// ============================================================
// ADEQ TOOLBAR — Configuración de API Keys v3
// ============================================================

export const CONFIG = {
  // ── Supabase (URL y anon key son públicas por diseño) ─────────
  SUPABASE_URL:      "https://ticjpwimhtfkbccchfyp.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRpY2pwd2ltaHRma2JjY2NoZnlwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ5MDE1MTksImV4cCI6MjA5MDQ3NzUxOX0.85xb7q52QHFsUZIqgOsogexMml--Ag1K3LY-a7cstyU",

  // ── Gmail OAuth (Client ID es público) ────────────────────────
  GMAIL_CLIENT_ID: "1006462691161-6uicvg6urcco0a50534c46l4jiclfm70.apps.googleusercontent.com",

  // ── API keys sensibles — se cargan en runtime desde toolbar_config ──
  // No hardcodear aquí. Se populan vía fetchApiKeys() tras el login.
  MONDAY_API_KEY:        "",
  MONDAY_ACTIVE_BOARD:   "1420268379",
  RAPIDAPI_KEY:          "",
  RAPIDAPI_TRAFFIC_HOST: "website-insights.p.rapidapi.com",
  GEMINI_API_KEY:        "",
  APOLLO_API_KEY:        "",

  // ── Monday columns (estructura, no secretos) ──────────────────
  MONDAY_BOARDS: { prospectos: "1420268379" },
  // Mapping: login email → Monday user ID (para columna Persona deal_owner)
  MONDAY_USER_IDS: {
    "mgargiulo@adeqmedia.com": 56851451, // Maximiliano
    "sales@adeqmedia.com":     60940538, // Agustina
    "dhorovitz@adeqmedia.com": 56938560, // Diego
  },
  MONDAY_COLUMNS: {
    nombre:          "name",
    estado:          "deal_stage",
    ejecutivo:       "deal_owner",       // person column
    fecha_contacto:  "deal_close_date",
    geo:             "texto6",
    trafico:         "texto7",
    idioma:          "estado_12",
    comentarios:     "texto",
    email:           "email_mm2edcd3",   // email column (was text_mkrwahsz)
    telefono:        "tel_fono_1",
    // Reengagement / Email Futuro — el agente actualiza estas dos al disparar
    // el envío automático del email_futuro (today+5 y today+10).
    // Verificar IDs en Monday si el push falla.
    fecha_fu1:       "fecha2",            // Fecha FU1 (today + 5 días) — Maxi 2026-07-15: era "fecha2_8" (id inexistente en board → "This column ID doesn't exist"); id real verificado contra el board = "fecha2"
    fecha_fu2:       "fecha_1",           // Fecha FU2 (today + 10 días)
  },

  // ── General ────────────────────────────────────────────────────
  MEDIA_BUYER: "Max",
  MIN_TRAFFIC: 350000,  // pageViews mínimos (visits × pagesPerVisit). Debajo: descartar. (User 2026-06-19: 350K pageviews; era 400K)
};
