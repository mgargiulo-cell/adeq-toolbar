// ============================================================
// ADEQ TOOLBAR — Gmail OAuth + Send  v3
//
// Uses chrome.identity.getAuthToken — the native Chrome Extension
// OAuth API. Works correctly for Internal Google Workspace apps
// (all @adeqmedia.com accounts authorized automatically).
//
// Token is cached by Chrome automatically. On 401, the cached
// token is removed and a fresh one is requested.
// ============================================================

import { CONFIG } from "../config.js";
import { crmUrl } from "./crm.js";

// ── LA MESA COMÚN TAMBIÉN CUENTA LO MANUAL (2026-09-07) ─────────────────────────────────
// `casilla_envios` (base del CRM) es el contador compartido de cuánto salió de cada buzón en
// la última hora: lo lee la cadencia del CRM para frenarse y lo lee el agente antes de cada
// turno. El worker registraba lo suyo; el popup, NO. Medido el 07/09: Agustina mandó 27 a mano
// desde sales@ y en la mesa figuraba 1. Los otros dos sistemas frenaban sobre un número que
// no incluía a la persona que más manda. Es fire-and-forget: nunca frena ni demora el envío.
function _registrarEnMesaComun(casilla, destino) {
  try {
    if (!casilla || !CONFIG.CRM_BOARD_SECRET) return;
    fetch(crmUrl("/casilla-envios"), {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-toolbar-secret": CONFIG.CRM_BOARD_SECRET },
      body: JSON.stringify({ casilla: String(casilla).toLowerCase().trim(), destino: String(destino || ""), origen: "toolbar", ref: null }),
      signal: AbortSignal.timeout(8000),
    }).catch(() => {});
  } catch {}
}

const GMAIL_SCOPES = [
  "https://www.googleapis.com/auth/gmail.send",
  "https://www.googleapis.com/auth/gmail.settings.basic",
  "https://www.googleapis.com/auth/userinfo.email",
];

// ── Core token fetch ──────────────────────────────────────────

function fetchToken(interactive) {
  return new Promise((resolve) => {
    chrome.identity.getAuthToken({ interactive, scopes: GMAIL_SCOPES }, (token) => {
      if (chrome.runtime.lastError || !token) {
        console.warn("[Gmail] getAuthToken:", chrome.runtime.lastError?.message);
        resolve(null);
      } else {
        resolve(token);
      }
    });
  });
}

function removeCachedToken(token) {
  return new Promise((resolve) => {
    chrome.identity.removeCachedAuthToken({ token }, resolve);
  });
}

// Limpia TODOS los tokens cacheados de Chrome para esta extensión.
// Se usa cuando los scopes cambian y necesitamos forzar un re-consent.
export async function clearAllCachedTokens() {
  return new Promise((resolve) => {
    chrome.identity.clearAllCachedAuthTokens(() => resolve());
  });
}

// ── Public API ────────────────────────────────────────────────

/**
 * Returns a valid Gmail access token.
 * @param {boolean} interactive - show OAuth window if needed
 * @returns {string|null}
 */
export async function getGmailToken(interactive = true) {
  return fetchToken(interactive);
}

/**
 * Returns the Gmail profile (real email address) of the authenticated Chrome user.
 * @param {boolean} interactive
 * @returns {{ email: string } | null}
 */
export async function getGmailProfile(interactive = false) {
  const token = await fetchToken(interactive);
  if (!token) return null;
  try {
    // tokeninfo funciona con cualquier token sin necesidad de scopes extra
    const res = await fetch(`https://oauth2.googleapis.com/tokeninfo?access_token=${encodeURIComponent(token)}`);
    if (res.status === 401 || res.status === 400) { await removeCachedToken(token); return null; }
    if (!res.ok) return null;
    const data = await res.json();
    return { email: (data?.email || "").toLowerCase() };
  } catch { return null; }
}

/**
 * Returns the Gmail signature (plain text) of the authenticated user.
 * @returns {string}
 */
export async function getGmailSignature() {
  try {
    const token = await fetchToken(false);
    if (!token) return "";

    const res = await fetch(
      "https://www.googleapis.com/gmail/v1/users/me/settings/sendAs",
      { headers: { "Authorization": `Bearer ${token}` } }
    );

    if (!res.ok) {
      if (res.status === 401) await removeCachedToken(token);
      return "";
    }

    const data    = await res.json();
    const primary = data.sendAs?.find(s => s.isDefault) || data.sendAs?.[0];
    const html    = primary?.signature || "";
    if (!html) return "";

    return html
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<\/p>/gi, "\n")
      .replace(/<\/div>/gi, "\n")
      .replace(/<\/tr>/gi, "\n")
      .replace(/<\/li>/gi, "\n")
      .replace(/<[^>]+>/g, "")
      .replace(/&nbsp;/gi, " ")
      .replace(/&amp;/gi, "&")
      .replace(/&lt;/gi, "<")
      .replace(/&gt;/gi, ">")
      .replace(/&quot;/gi, '"')
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  } catch { return ""; }
}

/**
 * Sends an email via Gmail API. If `expectedFrom` is provided,
 * verifies that Chrome's Google account matches before sending.
 * @param {{ to: string, subject: string, body: string, expectedFrom?: string }} params
 * @returns {{ ok: boolean, error?: string }}
 */
export async function sendEmail({ to, subject, body, expectedFrom }) {
  try {
    // Sanitizar recipient: URL-decode (%20 → espacio), strip zero-width, trim, lowercase.
    // Sin esto, scrapeos sucios tipo "%20info@x.com" o " info@x.com" rebotan en Gmail.
    try { to = decodeURIComponent(to); } catch {}
    to = String(to || "").replace(/[\s​‌‍﻿]+/g, "").toLowerCase();
    if (!/^[^\s@]{1,64}@[^\s@]{1,253}\.[^\s@]{2,}$/.test(to)) {
      throw new Error(`Recipient inválido tras sanitización: "${to}"`);
    }

    let token = await fetchToken(true);
    if (!token) throw new Error("Could not obtain Gmail token. Make sure Chrome is signed in with your @adeqmedia.com account.");

    // Validación estricta: si no podemos verificar la identidad del Gmail, NO enviamos.
    if (expectedFrom) {
      const expected = expectedFrom.toLowerCase().trim();

      const getEmailFromToken = async (tkn) => {
        try {
          const res = await fetch(`https://oauth2.googleapis.com/tokeninfo?access_token=${encodeURIComponent(tkn)}`);
          if (!res.ok) return { ok: false, status: res.status, email: "" };
          const data = await res.json().catch(() => ({}));
          return { ok: true, status: res.status, email: (data?.email || "").toLowerCase().trim() };
        } catch (e) {
          return { ok: false, status: 0, email: "", error: e.message };
        }
      };

      let result = await getEmailFromToken(token);

      // Si el token viejo no tiene scope email → limpiar caché y forzar re-auth
      if (result.ok && !result.email) {
        await removeCachedToken(token);
        token = await fetchToken(true);
        if (!token) throw new Error("No se pudo renovar el token de Gmail. Probá de nuevo.");
        result = await getEmailFromToken(token);
      }

      if (!result.ok && (result.status === 401 || result.status === 400)) {
        await removeCachedToken(token);
        throw new Error("Token de Gmail expirado. En Settings → Sign out Gmail → Sign in to Gmail.");
      }
      if (!result.ok) {
        throw new Error(`No se pudo verificar la identidad del Gmail (${result.error || "HTTP " + result.status}). No se envió el email.`);
      }
      if (!result.email) {
        throw new Error("El token no tiene permiso para leer el email. En Settings → Sign out Gmail → Sign in to Gmail y aceptá los permisos nuevos.");
      }
      if (result.email !== expected) {
        throw new Error(`⚠️ El Gmail de Chrome (${result.email}) no coincide con el login (${expected}). El email NO se envió. En Settings → Sign out Gmail → Sign in to Gmail con ${expected}.`);
      }
    }

    // Fetch user's default Gmail signature (HTML) — se appendea automáticamente
    // al body para que llegue con el formato real (logo, links, cargo, etc).
    const signatureHtml = await getGmailSignatureHtml(token);
    const raw = buildRaw({ to, subject, body, signatureHtml });

    let res = await fetch("https://www.googleapis.com/gmail/v1/users/me/messages/send", {
      method:  "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type":  "application/json",
      },
      body: JSON.stringify({ raw }),
    });

    // Token expired — remove and retry once with a fresh token
    if (res.status === 401) {
      await removeCachedToken(token);
      token = await fetchToken(true);
      if (!token) throw new Error("Authentication expired. Please try again.");

      res = await fetch("https://www.googleapis.com/gmail/v1/users/me/messages/send", {
        method:  "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type":  "application/json",
        },
        body: JSON.stringify({ raw }),
      });
    }

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || `Gmail error ${res.status}`);
    }

    _registrarEnMesaComun(expectedFrom, to);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

// ── Closing helper ────────────────────────────────────────────

const CLOSINGS = {
  en: "Best regards,",
  es: "Saludos,",
  pt: "Cumprimentos,",
  it: "Cordiali saluti,",
  fr: "Cordialement,",
  de: "Mit freundlichen Grüßen,",
  ar: "مع خالص التحيات,",
};

// Detecta si el body ya termina con un cierre (en cualquier idioma común).
const CLOSING_PATTERN = /\n\s*(best\s*regards|best|regards|saludos|un\s*saludo|cordialmente|atentamente|cumprimentos|abraços|cordiali\s*saluti|cordialement|mit\s*freundlichen\s*grüßen|cheers|thanks|thank\s*you|sincerely|kind\s*regards)[.,!\s]*\s*$/i;

/**
 * Si el body no termina con un cierre de email, agrega el apropiado para
 * el idioma. Si ya termina con uno, lo deja tal cual.
 * @param {string} body
 * @param {string} lang - código de idioma (en/es/pt/it/fr/de/ar)
 * @returns {string} body con cierre garantizado
 */
export function appendClosingIfMissing(body, lang = "es") {
  const trimmed = (body || "").trimEnd();
  if (!trimmed) return trimmed;
  if (CLOSING_PATTERN.test(trimmed)) return trimmed; // ya tiene cierre
  const closing = CLOSINGS[lang] || CLOSINGS.es;
  return `${trimmed}\n\n${closing}`;
}

// ── Internal helpers ──────────────────────────────────────────

// RFC 2047 encoded-word para headers con caracteres no-ASCII.
// Sin esto Gmail interpreta el subject como ISO-8859-1 → mojibake (ej "monetizaciÃƒÂ³n").
// Defensive: si el input YA viene double-encoded (UTF-8 leído como Latin-1, ej.
// "monetizaciÃ³n" en lugar de "monetización"), lo decodificamos antes de re-encodear.
const MOJIBAKE_PATTERN = /Ã[\x80-\xBF]|Â[¡¿«»]|â€[œ]/;
function _fixMojibake(str) {
  if (!MOJIBAKE_PATTERN.test(str)) return str;
  try {
    // Trick clásico: char codes vienen como Latin-1 → reinterpret as UTF-8
    const bytes = new Uint8Array(str.length);
    for (let i = 0; i < str.length; i++) bytes[i] = str.charCodeAt(i) & 0xFF;
    const decoded = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
    // Solo reemplazar si la decodificación produjo un string razonable
    // (más cortos en chars suele ser bueno; p.ej. "ó" pasa de 2 chars a 1)
    if (decoded && decoded.length <= str.length && !MOJIBAKE_PATTERN.test(decoded)) return decoded;
  } catch {}
  return str;
}
function encodeHeaderUtf8(value) {
  let str = String(value || "");
  // Reparar mojibake antes de encodear
  str = _fixMojibake(str);
  if (/^[\x20-\x7E]*$/.test(str)) return str; // ASCII puro: no encoding needed
  const bytes  = new TextEncoder().encode(str);
  const binary = String.fromCharCode(...bytes);
  return `=?UTF-8?B?${btoa(binary)}?=`;
}

// Convierte un body de texto plano a HTML preservando line breaks.
// Escapa HTML chars para evitar XSS si el pitch contiene <script>, etc.
function textToHtml(text) {
  return String(text || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\r\n/g, "\n")
    .split("\n\n")
    .map(p => `<p>${p.replace(/\n/g, "<br/>")}</p>`)
    .join("\n");
}

// Build raw MIME multipart/alternative (text/plain + text/html con signature).
// Si signatureHtml está vacío, fallback a text/plain solo (legacy behavior).
function buildRaw({ to, subject, body, signatureHtml = "" }) {
  let mime;
  if (signatureHtml && signatureHtml.trim()) {
    // Multipart: clientes texto-only ven plain, clientes modernos ven HTML con signature.
    const boundary = `----=adeq_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,10)}`;
    const plainBody = body; // sin signature en text/plain (Gmail web igual la aplica si responden)
    const htmlBody  = `${textToHtml(body)}\n<br/>\n${signatureHtml}`;
    mime = [
      `To: ${to}`,
      `Subject: ${encodeHeaderUtf8(subject)}`,
      "MIME-Version: 1.0",
      `Content-Type: multipart/alternative; boundary="${boundary}"`,
      "",
      `--${boundary}`,
      "Content-Type: text/plain; charset=utf-8",
      "Content-Transfer-Encoding: 8bit",
      "",
      plainBody,
      "",
      `--${boundary}`,
      "Content-Type: text/html; charset=utf-8",
      "Content-Transfer-Encoding: 8bit",
      "",
      htmlBody,
      "",
      `--${boundary}--`,
    ].join("\r\n");
  } else {
    // Fallback sin signature: text/plain solo
    mime = [
      `To: ${to}`,
      `Subject: ${encodeHeaderUtf8(subject)}`,
      "Content-Type: text/plain; charset=utf-8",
      "MIME-Version: 1.0",
      "",
      body,
    ].join("\r\n");
  }

  const bytes  = new TextEncoder().encode(mime);
  const binary = String.fromCharCode(...bytes);
  return btoa(binary)
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

// Fetch del HTML signature default del user. Cache en memoria por sesión.
let _cachedSignatureHtml = null;
async function getGmailSignatureHtml(token) {
  if (_cachedSignatureHtml !== null) return _cachedSignatureHtml;
  try {
    const res = await fetch(
      "https://www.googleapis.com/gmail/v1/users/me/settings/sendAs",
      { headers: { "Authorization": `Bearer ${token}` } }
    );
    if (!res.ok) return "";
    const data = await res.json();
    const primary = data.sendAs?.find(s => s.isDefault) || data.sendAs?.[0];
    _cachedSignatureHtml = primary?.signature || "";
    return _cachedSignatureHtml;
  } catch { return ""; }
}
