// ============================================================
// ADEQ TOOLBAR — Módulo Monday.com v3
// ============================================================

import { CONFIG } from "../config.js";

const MONDAY_API = "https://api.monday.com/v2";

// Maxi 2026-07-01 (B7): columna de índice (estado/idioma) SOLO si el valor es un entero
// válido. Antes parseInt(x) sobre un string no-numérico daba NaN → {index:null} → Monday
// podía blanquear/rechazar la columna. Ahora si no es entero, se omite la columna entera.
function _mondayIndexCol(val) {
  if (val === undefined || val === null || val === "") return null;
  const n = parseInt(val, 10);
  return Number.isInteger(n) ? { index: n } : null;
}

async function mondayRequest(query, { timeoutMs = 15000 } = {}) {
  if (!CONFIG.MONDAY_API_KEY) {
    throw new Error("Monday API key no cargada (sesión expirada o sin permisos)");
  }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const response = await fetch(MONDAY_API, {
      method: "POST",
      headers: {
        "Content-Type":  "application/json",
        "Authorization": CONFIG.MONDAY_API_KEY,
        "API-Version":   "2024-01",
      },
      body: JSON.stringify({ query }),
      signal: ctrl.signal,
    });
    if (!response.ok) throw new Error(`Monday API error: ${response.status}`);
    const json = await response.json();
    if (json.errors) throw new Error(json.errors[0]?.message || "Error en Monday API");
    return json.data;
  } catch (e) {
    if (e.name === "AbortError") throw new Error(`Monday timeout (${timeoutMs}ms)`);
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

export async function checkDuplicate(domain) {
  const domainClean = cleanDomain(domain).replace(/"/g, "").replace(/\\/g, "");
  const query = `{
    boards(ids: [${CONFIG.MONDAY_ACTIVE_BOARD}]) {
      items_page(limit: 500, query_params: {
        rules: [{ column_id: "name", compare_value: ["${domainClean}"], operator: contains_text }]
      }) {
        items {
          id name
          column_values(ids: [
            "${CONFIG.MONDAY_COLUMNS.estado}",
            "${CONFIG.MONDAY_COLUMNS.ejecutivo}",
            "${CONFIG.MONDAY_COLUMNS.trafico}",
            "${CONFIG.MONDAY_COLUMNS.email}",
            "${CONFIG.MONDAY_COLUMNS.geo}",
            "${CONFIG.MONDAY_COLUMNS.fecha_contacto}",
            "${CONFIG.MONDAY_COLUMNS.idioma}"
          ]) { id text }
        }
      }
    }
  }`;

  const data  = await mondayRequest(query);
  const items = data?.boards?.[0]?.items_page?.items || [];
  const match = items.find(item => cleanDomain(item.name) === domainClean);
  if (!match) return { found: false };

  const col = (id) => match.column_values.find(c => c.id === id)?.text || "";
  return {
    found:     true,
    itemId:    match.id,
    status:    col(CONFIG.MONDAY_COLUMNS.estado),
    ejecutivo: col(CONFIG.MONDAY_COLUMNS.ejecutivo),
    trafico:   col(CONFIG.MONDAY_COLUMNS.trafico),
    email:     col(CONFIG.MONDAY_COLUMNS.email),
    geo:       col(CONFIG.MONDAY_COLUMNS.geo),
    fecha:     col(CONFIG.MONDAY_COLUMNS.fecha_contacto),
    idioma:    col(CONFIG.MONDAY_COLUMNS.idioma),
  };
}

// Resuelve el user ID de Monday a partir del login email o el nombre corto
function resolveMondayPerson(ejecutivo, loginEmail) {
  if (loginEmail) {
    const id = CONFIG.MONDAY_USER_IDS?.[loginEmail.toLowerCase()];
    if (id) return id;
  }
  const shortToEmail = {
    "Max":   "mgargiulo@adeqmedia.com",
    "Agus":  "sales@adeqmedia.com",
    "Diego": "dhorovitz@adeqmedia.com",
  };
  if (ejecutivo && shortToEmail[ejecutivo]) {
    const id = CONFIG.MONDAY_USER_IDS?.[shortToEmail[ejecutivo]];
    if (id) return id;
  }
  return null;
}

export async function pushToMonday(data) {
  const { domain, traffic, email, geo, estado, fecha, idioma, ejecutivo, loginEmail } = data;

  const safe     = (str) => (str || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\r/g, "\\r").replace(/\n/g, "\\n").replace(/\t/g, "\\t");
  // Normaliza: quita protocolo/trailing slash, fuerza www. prefix
  const cleaned  = String(domain || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/\/+$/, "");
  const itemName = cleaned.startsWith("www.") ? cleaned : `www.${cleaned}`;

  const personId = resolveMondayPerson(ejecutivo, loginEmail);

  // Comentarios = ORIGEN del lead (Maxi 2026-07-21, pedido del user): push MANUAL del MB → "Manual".
  // El push del AGENTE (auto-prospector: pushToMondayServer) escribe "Agente". Desde hoy TODO item
  // lleva identificación en Comentarios. NO es el pitch (eso el user no lo quiere ahí).
  const columnValues = {
    // Maxi 2026-08-10: la marca de origen vivía SOLO en Comentarios, que es texto libre — el
    // primer MB que anota algo ahí la borra. De ahí el "a veces figura y a veces no". Si hay una
    // columna dedicada configurada, va ahí; Comentarios se sigue completando por compatibilidad.
    ...(CONFIG.MONDAY_COLUMNS.origen ? { [CONFIG.MONDAY_COLUMNS.origen]: "Manual" } : {}),
    [CONFIG.MONDAY_COLUMNS.comentarios]:   "Manual",
    [CONFIG.MONDAY_COLUMNS.trafico]:       safe(String(traffic || "")),
    [CONFIG.MONDAY_COLUMNS.geo]:           safe(geo || ""),
    ...(email                                                             ? { [CONFIG.MONDAY_COLUMNS.email]:         { email: email, text: email } } : {}),
    ...(personId                                                          ? { [CONFIG.MONDAY_COLUMNS.ejecutivo]:     { personsAndTeams: [{ id: personId, kind: "person" }] } } : {}),
    ...(_mondayIndexCol(estado) ? { [CONFIG.MONDAY_COLUMNS.estado]: _mondayIndexCol(estado) } : {}),
    ...(fecha                               ? { [CONFIG.MONDAY_COLUMNS.fecha_contacto]: { date: fecha } }             : {}),
    ...(_mondayIndexCol(idioma) ? { [CONFIG.MONDAY_COLUMNS.idioma]: _mondayIndexCol(idioma) } : {}),
  };

  const mutation = `mutation {
    create_item(
      board_id: ${CONFIG.MONDAY_ACTIVE_BOARD},
      item_name: "${safe(itemName)}",
      column_values: "${safe(JSON.stringify(columnValues))}"
    ) { id name }
  }`;

  const result = await mondayRequest(mutation);
  return result?.create_item;
}

export async function updateMonday({ itemId, traffic, email, geo, estado, fecha, idioma, ejecutivo, loginEmail }) {
  const safe = (str) => (str || "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n");

  const personId = resolveMondayPerson(ejecutivo, loginEmail);

  // Comentarios: NO se incluye pitch — decisión user 2026-05-12.
  // Maxi 2026-08-10: la marca de origen se escribía SOLO al CREAR el item. Los dominios que ya
  // estaban en el board —miles, desde 2024— pasan por acá y se quedaban sin marca. Ese era el
  // "a veces sí y a veces no": no es aleatorio, es si el item es nuevo o ya existía.
  // Verificado en el board con tres items de la misma marca:
  //   fr.besoccer.com      creado hoy   → "Agente"
  //   www.es.besoccer.com  creado 2024  → ""
  //   company.besoccer.com creado 06/26 → null
  // Un push manual siempre lo hace un MB, así que la marca es correcta también al actualizar.
  const columnValues = {
    ...(CONFIG.MONDAY_COLUMNS.origen ? { [CONFIG.MONDAY_COLUMNS.origen]: "Manual" } : {}),
    [CONFIG.MONDAY_COLUMNS.comentarios]:   "Manual",
    [CONFIG.MONDAY_COLUMNS.trafico]:       safe(String(traffic || "")),
    [CONFIG.MONDAY_COLUMNS.geo]:           safe(geo || ""),
    ...(email                                                             ? { [CONFIG.MONDAY_COLUMNS.email]:         { email: email, text: email } } : {}),
    ...(personId                                                          ? { [CONFIG.MONDAY_COLUMNS.ejecutivo]:     { personsAndTeams: [{ id: personId, kind: "person" }] } } : {}),
    ...(_mondayIndexCol(estado) ? { [CONFIG.MONDAY_COLUMNS.estado]: _mondayIndexCol(estado) } : {}),
    ...(fecha                               ? { [CONFIG.MONDAY_COLUMNS.fecha_contacto]: { date: fecha } }             : {}),
    ...(_mondayIndexCol(idioma) ? { [CONFIG.MONDAY_COLUMNS.idioma]: _mondayIndexCol(idioma) } : {}),
  };

  const mutation = `mutation {
    change_multiple_column_values(
      item_id: ${itemId},
      board_id: ${CONFIG.MONDAY_ACTIVE_BOARD},
      column_values: "${safe(JSON.stringify(columnValues))}"
    ) { id name }
  }`;

  return mondayRequest(mutation);
}

export const MONDAY_STATES = {
  LIVE:              { index: "0",  label: "LIVE" },
  EN_NEGOCIACION:    { index: "1",  label: "En Negociacion" },
  DESCARTADO:        { index: "2",  label: "Descartado" },
  PROPUESTA_VIGENTE: { index: "3",  label: "Propuesta Vigente" },
  REBOTADO:          { index: "4",  label: "Rebotado" },
  CICLO_FINALIZADO:  { index: "5",  label: "Ciclo Finalizado" },
  MASIVO_DIEGO:      { index: "6",  label: "Masivo - Diego" },
  AVANZADO:          { index: "7",  label: "Avanzado" },
  MAIL_NO_ENVIADO:   { index: "8",  label: "Mail No Enviado" },
  MASIVO_AGUS:       { index: "9",  label: "Masivo - Agus" },
  MASIVO_MAX:        { index: "10", label: "Masivo - Max" },
};

export const RECYCLABLE_STATES = ["Ciclo Finalizado", "Rebotado", "Descartado"];

// ── Board index para filtrado en cascada ──────────────────────
// Devuelve Map<domainClean, { ejecutivo, fecha }>
export async function getMondayBoardIndex() {
  const query = `{
    boards(ids: [${CONFIG.MONDAY_ACTIVE_BOARD}]) {
      items_page(limit: 500) {
        items {
          name
          column_values(ids: [
            "${CONFIG.MONDAY_COLUMNS.ejecutivo}",
            "${CONFIG.MONDAY_COLUMNS.fecha_contacto}",
            "${CONFIG.MONDAY_COLUMNS.estado}"
          ]) { id text }
        }
      }
    }
  }`;

  try {
    const data  = await mondayRequest(query);
    const items = data?.boards?.[0]?.items_page?.items || [];
    const index = new Map();
    for (const item of items) {
      const col = (id) => item.column_values.find(c => c.id === id)?.text || "";
      index.set(cleanDomain(item.name), {
        ejecutivo: col(CONFIG.MONDAY_COLUMNS.ejecutivo),
        fecha:     col(CONFIG.MONDAY_COLUMNS.fecha_contacto),
        estado:    col(CONFIG.MONDAY_COLUMNS.estado),
      });
    }
    return index;
  } catch (e) {
    console.warn("[getMondayBoardIndex] failed:", e.message);
    return new Map();
  }
}

function cleanDomain(str) {
  return (str || "").toLowerCase()
    .replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\/$/, "").trim();
}

// Parsea strings de tráfico de Monday a número entero.
// Acepta sufijos K/M/B (mayúsc o minúsc), decimales con `.` o `,` (estilo europeo),
// separadores de miles, espacios y texto extra (ej: "500 vistas", "1,5 M", "2.5m").
export function parseTrafficText(str) {
  if (str == null) return 0;
  let s = String(str).trim();
  if (!s) return 0;

  // Detectar sufijo K/M/B en cualquier posición, ignorando case
  const upper = s.toUpperCase();
  let mult = 1;
  if (/[MB]/.test(upper))      mult = upper.includes("B") ? 1_000_000_000 : 1_000_000;
  else if (/K/.test(upper))    mult = 1_000;

  if (mult > 1) {
    // Con sufijo: extraer el primer número (decimal con . o ,)
    const m = upper.match(/(\d+(?:[.,]\d+)?)/);
    if (!m) return 0;
    const n = parseFloat(m[1].replace(",", "."));
    return isNaN(n) ? 0 : Math.round(n * mult);
  }

  // Sin sufijo: tratar . y , como separadores de miles → quedarse solo con dígitos
  const digits = s.replace(/[^\d]/g, "");
  return digits ? parseInt(digits, 10) : 0;
}

// ── fetchMondayForRefresh — para MONDAY CSV AUTO PROSPECTOR ─────
// Trae dominios ya en Monday con estado "Ciclo Finalizado" filtrado por geo/idioma,
// para re-prospectarlos en batch sin necesidad de CSV
export async function fetchMondayForRefresh({ geo = "", idioma = "", limit = 75 } = {}) {
  const rules = [];
  // Estado "Ciclo Finalizado" = index 5 (obligatorio)
  rules.push(`{ column_id: "${CONFIG.MONDAY_COLUMNS.estado}", compare_value: [5], operator: any_of }`);
  if (idioma !== "") rules.push(`{ column_id: "${CONFIG.MONDAY_COLUMNS.idioma}", compare_value: [${parseInt(idioma)}], operator: any_of }`);
  if (geo)           rules.push(`{ column_id: "${CONFIG.MONDAY_COLUMNS.geo}", compare_value: "${geo}", operator: contains_text }`);

  const queryParams = `, query_params: { rules: [${rules.join(",")}] }`;

  let cursor   = null;
  let allItems = [];

  // Pool máximo a traer ANTES de mezclar. Si solo trajéramos `limit`, Monday
  // siempre devuelve los más recientes → mismos 75 → "0 added — all known".
  // Con 1000 de pool, hay mucha más probabilidad de pegar leads viejos no
  // procesados al hacer el shuffle.
  const POOL_MAX = Math.max(1000, limit * 10);

  try {
    do {
      const pageArgs = cursor
        ? `cursor: "${cursor}", limit: 500`
        : `limit: 500${queryParams}`;

      const query = `{
        boards(ids: [${CONFIG.MONDAY_ACTIVE_BOARD}]) {
          items_page(${pageArgs}) {
            cursor
            items { name }
          }
        }
      }`;

      const data = await mondayRequest(query);
      const page = data?.boards?.[0]?.items_page;
      allItems   = [...allItems, ...(page?.items || [])];
      cursor     = page?.cursor || null;

      if (allItems.length >= POOL_MAX) break;
    } while (cursor);

    // Limpia dominios + dedup en memoria
    const pool = [...new Set(
      allItems
        .map(it => cleanDomain(it.name))
        .filter(Boolean)
    )];

    // Shuffle (Fisher-Yates) → garantiza rotación entre leads viejos y nuevos.
    // Antes la query siempre devolvía los más recientes primero y caía en el
    // bucle "siempre los mismos 75 — todos ya conocidos".
    for (let i = pool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [pool[i], pool[j]] = [pool[j], pool[i]];
    }

    return pool.slice(0, limit);
  } catch (e) {
    console.error("[Refresh] fetchMondayForRefresh error:", e.message);
    throw new Error(`Monday API: ${e.message}`);
  }
}

// ── fetchImportCandidates — para el tab Import ────────────────
// Trae ítems del board con estado "Ciclo Finalizado" filtrados por geo/idioma
export async function fetchImportCandidates({ geo = "", idioma = "", minTraffic = 0, maxTraffic = 0 } = {}) {
  const rules = [];
  // Estado "Ciclo Finalizado" (id 5) — SIEMPRE se filtra por este estado
  rules.push(`{ column_id: "${CONFIG.MONDAY_COLUMNS.estado}", compare_value: [5], operator: any_of }`);
  // idioma: status column con ID numérico — Monday requiere número, no string
  if (idioma !== "") rules.push(`{ column_id: "${CONFIG.MONDAY_COLUMNS.idioma}", compare_value: [${parseInt(idioma)}], operator: any_of }`);
  // geo: text column, contains_text espera un string (no array)
  if (geo)           rules.push(`{ column_id: "${CONFIG.MONDAY_COLUMNS.geo}", compare_value: "${geo}", operator: contains_text }`);

  const queryParams = rules.length
    ? `, query_params: { rules: [${rules.join(",")}] }`
    : "";

  // Collect all items using cursor pagination (Monday max 500/page)
  let cursor   = null;
  let allItems = [];

  try {
    do {
      // Monday rule: query_params SOLO en la primera request; subsequent usan solo cursor
      let pageArgs;
      if (cursor) {
        pageArgs = `cursor: "${cursor}", limit: 500`;
      } else {
        pageArgs = `limit: 500${queryParams}`;
      }

      const query = `{
        boards(ids: [${CONFIG.MONDAY_ACTIVE_BOARD}]) {
          items_page(${pageArgs}) {
            cursor
            items {
              name
              column_values(ids: [
                "${CONFIG.MONDAY_COLUMNS.trafico}",
                "${CONFIG.MONDAY_COLUMNS.geo}",
                "${CONFIG.MONDAY_COLUMNS.idioma}",
                "${CONFIG.MONDAY_COLUMNS.estado}"
              ]) { id text }
            }
          }
        }
      }`;

      const data = await mondayRequest(query);
      const page = data?.boards?.[0]?.items_page;
      allItems   = [...allItems, ...(page?.items || [])];
      cursor     = page?.cursor || null;
    } while (cursor);

    return allItems
      .map(item => {
        const col     = (id) => item.column_values.find(c => c.id === id)?.text || "";
        const traffic = parseTrafficText(col(CONFIG.MONDAY_COLUMNS.trafico));
        const domain  = cleanDomain(item.name);
        const estado  = col(CONFIG.MONDAY_COLUMNS.estado);
        return { domain, url: `https://www.${domain}`, traffic, geo: col(CONFIG.MONDAY_COLUMNS.geo), idioma: col(CONFIG.MONDAY_COLUMNS.idioma), estado };
      })
      .filter(item => item.domain)
      .filter(item => !minTraffic || item.traffic >= minTraffic)
      .filter(item => !maxTraffic || item.traffic <= maxTraffic);

  } catch (e) {
    console.error("[Import] fetchImportCandidates error:", e.message);
    return [];
  }
}
